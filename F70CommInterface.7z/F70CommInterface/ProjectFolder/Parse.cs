﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TextParser
{
    class ParseMessage
    {
        public static string RemoveGarbageAndFormatResponse(string receivedMsg, string cmd)
        {
            string[] tmp = receivedMsg.Split(new string[] {"\n", "\r\n"}, StringSplitOptions.RemoveEmptyEntries);
            string[] buffer = tmp[4].Split(',');    //buffer[0] = "$TEA", "$PRA", etc.

            //handles the Last 3 commands
            if (cmd == "h\r\n" || cmd == "f\r\n")
            {
                tmp = tmp.Skip(4).ToArray();

                return string.Join("\r\n", tmp).TrimStart('\r','\n').Replace(":", ": "); ;
            }
            
            //Handles the other commands
            switch (buffer[0])
            {
                case "$TEA":
                    return ParseTemp(tmp[4]);

                case "$PRA":
                    return ParsePressure(tmp[4]);

                case "$STA":
                    return ParseStatusBits(tmp[4]);

                case "$ID1":
                    return ParseFirmwareAndElapsedHours(tmp[4]);

                default:
                    if (cmd[0] != '$')
                        return "Bad command / bad parse";
                    else
                        return receivedMsg;     //if it's an operating command, this triggers
            }
            
        }

        //T4 inactive on most F70 variants
        public static string ParseTemp(string s)
        {
            string[] split = s.Split(',');
            string[] formattedResponse = { "Compressor capsule helium discharge temperature: ", "Water outlet temperature: ", "Water inlet temperature: " };

            //loop to format values
            bool ignore = false;
            for (int i = 0; i < 3; i++)
            {
                if (split[i + 1] == "000")
                {
                    formattedResponse[i] = "0";
                    ignore = true;
                }

                if (!ignore)
                {
                    formattedResponse[i] += split[i + 1].TrimStart('0') + "°C";
                }

                Console.WriteLine(formattedResponse[i]);
            }

            return string.Join(Environment.NewLine, formattedResponse);
        }

        public static string ParsePressure(string s)
        {
            string[] split = s.Split(',');
            string formattedResponse = "Compressor return pressure: ";

            return formattedResponse + split[1].TrimStart('0') + " psig";
        }

        public static string ParseFirmwareAndElapsedHours(string s)
        {
            string[] split = s.Split(',');
            string[] formattedResponse = {"Firmware Version: ", "Elapsed operating hours: "};

            foreach (string q in split)
                Console.WriteLine(q);

            formattedResponse[0] += split[1];
            formattedResponse[1] += split[2].TrimStart('0') + " hrs";

            return string.Join(Environment.NewLine, formattedResponse);
        }

        public static string ParseStatusBits(string s)
        {
            //Get Binary string from 4-digit Hex
            string[] split = s.Split(',');
            char[] hexDigits = split[1].ToCharArray();

            string binaryString = String.Empty;
            for (int i = 0; i < 4; i++)
            {
                string tmp = String.Join(String.Empty, hexDigits[i].ToString().Select(
                    c => Convert.ToString(Convert.ToInt32(c.ToString(), 16), 2).PadLeft(4, '0')));
                binaryString += tmp;
            }

            string[] stateBits = { "Local OFF", "Local ON", "Remote OFF", "Remote ON", "Cold Head Run", "Cold Head Pause", "Fault OFF", "Oil Fault OFF" };

            var bits = new (string, string)[] {
                ("System OFF.", "System ON"),                                     // [0]  (system off/on)
                ("Motor Temperature OK", "Motor Temperature Alarm"),              // [1]  (motor temp alarm)
                ("Phase Sequence/Fuses OK", "Phase Sequence / Fuse Alarm"),       // [2]  (phase seq/fuses alarm)
                ("Helium Temperature OK", "Helium Temperature Alarm"),            // [3]  (helium temp alarm)
                ("Water Temperature OK", "Water Temperature Alarm"),              // [4]  (water temp alarm)
                ("Water Flow OK", "Water Flow Alarm"),                            // [5]  (water flow alarm)
                ("Oil Level OK", "Oil Level Alarm"),                              // [6]  (oil level alarm)
                ("Pressure Level OK", "Pressure Level Alarm"),                    // [7]  (pressure level alarm)
                ("Solenoid OFF", "Solenoid ON"),                                  // [8]  (solenoid on/off)
                (" ", " "),                                                       // [9]  (LSbit of state #) \
                (" ", " "),                                                       // [10] (Mbit of state #)	  > not converted to "0" or "1" on purpose.
                (" ", " "),                                                       // [11] (MSbit of state #) /
                (" ", " "),                                                       // [12] (spare)
                (" ", " "),                                                       // [13] (spare)
                (" ", " "),                                                       // [14] (spare)
                ("Configuration 1", "Configuration 2")                            // [15] (configuration)
            };

            /*	Format: Bit 0 is the LEAST significant bit (furthest right)	 */
            bool go = true;
            var statusBitList = new List<string>();
            for (int i = 0; i < binaryString.Length; i++)
            {
                if (i > 0 && i < 7) go = false;
                if (go)
                {
                    if (binaryString[i] - 48 == 1)
                        statusBitList.Add(bits[15 - i].Item2);
                    else if (binaryString[i] - 48 == 0)
                        statusBitList.Add(bits[15 - i].Item1);
                }
                go = true;
            }

            //state bit calculation
            string threeBits = (binaryString[4] - 48).ToString() + (binaryString[5] - 48).ToString() + (binaryString[6] - 48).ToString();
            int intValue = Convert.ToInt32(threeBits);
            for (int i = 0; i < stateBits.Length - 1; i++)
                if (i == intValue)
                    statusBitList.Add(stateBits[i]);

            var statusBitArray = statusBitList.ToArray();
            return string.Join(Environment.NewLine, statusBitArray);
        }
    }
}