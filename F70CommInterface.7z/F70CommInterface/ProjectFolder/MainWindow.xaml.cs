﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using TextParser;


namespace TextParser
{
    public partial class MainWindow : Window
    {
        //carriage return is hard-coded for windows environments
        public Dictionary<string,string> Commands => new Dictionary<string, string>()
        {
            {"$TEA - Read All Temperatures", "$TEAA4B9\r\n"},
            {"$PRA - Read All Pressures", "$PRA95F7\r\n"},
            {"$STA - Read Status Bits","$STA3504\r\n"},
            {"$ID1 - Read Firmware Version and Elapsed Hours","$ID1D629\r\n"},
            {"$ON1 - Turn ON Compressor and Cold Head","$ON177CF\r\n"},
            {"$OFF - Turn OFF Compressor and Cold Head","$OFF9188\r\n"},
            {"$RS1 - Reset Faults","$RS12156\r\n"},
            {"$CHR - Cold Head Run","$CHRFD4C\r\n"},
            {"$CHP - Cold Head Pause","$CHP3CCD\r\n"},
            {"$POF - Cold Head Unpause","$POF07BF\r\n"},
            {"Adsorber Life","f\r\n"},
            {"Display Last 20 Failures","h\r\n"}
        };

        public string[] informationCommandDescriptions =
        {
                "$TEA: Read all temperatures. Temperature fields are always 3 characters long and are rounded to the nearest degree. Temperatures less than 100C have leading 0's.\n",
                "$PRA: Read all pressures. Units in psig. If inactive, compressor will return '000'. Pressures less than 100 psig will have leading 0's.\n",
                "$STA: Read Status bits. Returns a 4-digit HEX number, which when converted to binary will read the status of the compressor.\n",
                "$ID1: Read firmware version and elapsed operating hours - version # is a 3-character text field (X.X) and the elapsed hours are an 8 character text field with preceding 0's if it's a value less than 10,000,000 hours.\n"
        };

        public string[] operatingCommandDescriptions =
        {
                "$ON1: When the compressor is off and without active fault, this will turn the compressor and cold head on. If the compressor is in another state when this command is sent, a response will be returned, but no action will occur.\n",
                "$OFF: When the compressor and/or cold head is on, this will turn either or both off. If the command is sent while the compressor and cold head are off, the RS232 response will be returned, but no action will occur.\n",
                "$RS1: Clears fault indications from the RS232 status response, DB25 diagnostic interface, and LCD display, and, if the compressor is in Fault Off state(off because of fault), compressor will go to OFF state. If the command is sent while no faults are indicated or not in Fault Off state, the RS232 response will be returned, but no action will occur.\n",
                "$CHR: When the compressor is off, this will turn on the cold head only. If no subsequent off command is received, the cold head will turn off automatically after 30 minutes.If the command is sent while the compressor is not in an OFF state, the RS232 response will be returned, but no action will occur.\n",
                "$CHP: When the compressor and cold head are on, this will turn off the cold head only. If the command is sent while the compressor is not in an On state, the RS232 response will be returned, but no action will occur.\n",
                "$POF: When the compressor is on with the cold head off (Cold Head Pause state), this will turn the cold head back on(return to normal ON state). If the command is sent while the compressor is not in Cold Head Pause state, the RS232 response will be returned, but no action will occur.\n"
        };

        public string[] stateBits = { "Local OFF", "Local ON", "Remote OFF", "Remote ON", "Cold Head Run", "Cold Head Pause", "Fault OFF", "Oil Fault OFF" };

        public MainWindow()
        {
            InitializeComponent();
        }

        public string SourceUri { get { return Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "ProNovaLogo.png"); } }

        //SEND COMMAND
        private void SendCommand_Button_OnClick(object sender, RoutedEventArgs e)
        {
            var cmd = CommandComboBox.SelectedValue.ToString();
            var msg = TcpConnect(cmd);
            DeviceResponseTextBox.Text = msg;
        }

        //HELP MENU
        private void OpenHelpMenu_Button_OnClick(object sender, RoutedEventArgs e)
        {
            string[] combined = informationCommandDescriptions.Union(operatingCommandDescriptions).ToArray();
            string toDisplay = string.Join(Environment.NewLine, combined);
            MessageBox.Show(toDisplay);
        }

        //CONNECT TO EDS4100
        public string TcpConnect(string cmd) {
            var client = new TcpClient();
            client.ReceiveTimeout = 1000;

            Console.WriteLine("Connecting to server");

            try { client.Connect("169.254.20.40", 23); }
            catch
            {
                MessageBox.Show("Failed to Connect to EDS4100");
                return String.Empty;
            }
            

            Console.WriteLine("CONNECTED SUCCESSFULLY");

            Stream tcpStream = client.GetStream();

            //handshake goes into garbage variable
            byte[] trash = new byte[20];
            var garbage = tcpStream.Read(trash, 0, trash.Length); 

            ASCIIEncoding A = new ASCIIEncoding();
            byte[] enable = A.GetBytes("enable" + Environment.NewLine);
            byte[] connect = A.GetBytes("connect line 1" + Environment.NewLine);
            byte[] ba = A.GetBytes(cmd);

            Console.WriteLine("Transmitting.....");

            tcpStream.Write(enable, 0, enable.Length);
            tcpStream.Write(connect, 0, connect.Length);
            tcpStream.Write(ba, 0, ba.Length);

            byte[] responseBytes = new byte[4096];

            //loops until no more data is received
            string receivedMsg = String.Empty;
            try
            {
                int numBytesRead;
                while ((numBytesRead = tcpStream.Read(responseBytes, 0, responseBytes.Length)) != 0)
                {
                    receivedMsg += A.GetString(responseBytes, 0, numBytesRead);
                }
            }
            catch (Exception)
            {
                Console.WriteLine("purposeful exception has been thrown");
                client.Close();
                tcpStream.Close();
                Console.WriteLine("\nConnection Closed.");

                return ParseMessage.RemoveGarbageAndFormatResponse(receivedMsg, cmd);
            }

            client.Close();
            tcpStream.Close();

            return "ERROR";
        }

    }

}
